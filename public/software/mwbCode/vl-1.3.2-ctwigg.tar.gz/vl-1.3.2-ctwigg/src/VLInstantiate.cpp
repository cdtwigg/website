/*
	File:		VLInstantiate.cpp
	
	Purpose:	(Attempt to) instantiate templates used by functions in the
				VL library.
	
	Author:		Andrew Willmott
*/

#include "cl\Array.cpp"

// Instantiate float and double arrays, if possible.
// (Unfortunately, many C++ compilers don't yet support the
// ANSI syntax for doing this. It's not a disaster if they
// don't, as, unless the compiler is really broken, it
// should automatically instantiate the templates at
// compile time.


#ifdef CL_SGI_INST
#pragma instantiate vl::Array<Float>
#pragma instantiate vl::Array<Double>

#pragma instantiate vl::Array<Array<Float> >
#pragma instantiate vl::Array<Array<Double> >

#include "vl\VLf.h"
#include "vl\VLd.h"

#pragma instantiate vl::Array<SparsePaird>
#pragma instantiate vl::Array<SparsePairf>
#pragma instantiate vl::Array<SparseVecd>
#pragma instantiate vl::Array<SparseVecf>

#if 1
#pragma instantiate istream &operator>>(istream&, vl::Array<Double>&)
#pragma instantiate istream &operator>>(istream&, vl::Array<Array<Double> >&)
#pragma instantiate istream &operator>>(istream&, vl::Array<SparseVecd>&)
#pragma instantiate istream &operator>>(istream&, vl::Array<Float>&)
#pragma instantiate istream &operator>>(istream&, vl::Array<Array<Float> >&)
#pragma instantiate istream &operator>>(istream&, vl::Array<SparseVecf>&)
#if 0
#pragma instantiate istream &operator>>(istream&, vl::Array<SparsePaird>&)
#pragma instantiate istream &operator>>(istream&, vl::Array<SparsePairf>&)
#endif
#endif

#elif defined(CL_TMPL_INST)

#if 0
template class vl::Array<VL_V_REAL>;
template class vl::Array<Array<VL_V_REAL> >;
template class vl::Array<VL_V_SUFF(SparsePair)>;
template class vl::Array<Array<VL_V_SUFF(SparsePair) > >;
#endif

#endif
