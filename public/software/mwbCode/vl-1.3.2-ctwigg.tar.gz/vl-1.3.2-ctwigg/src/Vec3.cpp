/*
	File:			Vec3.cpp

	Function:		Implements Vec3.h

	Author(s):		Andrew Willmott

	Copyright:		(c) 1995-2000, Andrew Willmott

	Notes:			

*/


#include "vl\Vec3.h"
#include <cctype>
#include <iostream>
#include <iomanip>

namespace vl {

std::ostream &operator << (std::ostream &s, const vl::TVec3 &v)
{
	vl::Int w = s.width();

	return(s << '[' << v[0] << ' ' << std::setw(w) << v[1] << ' ' << std::setw(w) << v[2] << ']');
}

std::istream &operator >> (std::istream &s, vl::TVec3 &v)
{
	vl::TVec3	result;
	vl::Char	c;
	
	// Expected format: [1 2 3]
	
    while (s >> c && isspace(c))		
		;
		
    if (c == '[')						
    {
		s >> result[0] >> result[1] >> result[2];	

		if (!s)
		{
			std::cerr << "Error: Expected number while reading vector\n";
			return(s);
		}
			
		while (s >> c && isspace(c))
			;
			
		if (c != ']')
    	{
    		s.clear(std::ios::failbit);
	    	std::cerr << "Error: Expected ']' while reading vector\n";
	    	return(s);
    	}
	}
    else
	{
	    s.clear(std::ios::failbit);
	    std::cerr << "Error: Expected '[' while reading vector\n";
	    return(s);
	}
	
	v = result;
    return(s);
}

} // namespace vl

