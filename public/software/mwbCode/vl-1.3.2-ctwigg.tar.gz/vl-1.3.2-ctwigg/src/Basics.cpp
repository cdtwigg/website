/*
	File:			Basics.cpp

	Function:		Implements Basics.h

	Author(s):		Andrew Willmott

	Copyright:		(c) 1995-2000, Andrew Willmott

	Notes:			

*/

#include "cl\Basics.h"
#include <cstdio>
#include <cstdlib>
#include <iostream>


// --- Error functions for range and routine checking -------------------------

namespace vl
{

static Void DebuggerBreak()
{
	abort();
}

Void _Assert(Int condition, const Char *errorMessage, const Char *file, Int line)
{
	if (!condition)
	{
		Char reply;
		
		std::cerr << "\n*** Assert failed (line " << line << " in " << 
			file << "): " << errorMessage << std::endl;
		std::cerr << "    Continue? [y/n] ";
		std::cin >> reply;
		
		if (reply != 'y')
		{
			DebuggerBreak();
			exit(1);
		}
	}
}

Void _Expect(Int condition, const Char *warningMessage, const Char *file, Int line)
{
	if (!condition)
		std::cerr << "\n*** Warning (line " << line << " in " << file << "): " <<
			warningMessage << std::endl;
}

Void _CheckRange(Int i, Int lowerBound, Int upperBound, 
				 const Char *rangeMessage, const Char *file, Int line)
{
	if (i < lowerBound || i >= upperBound)
	{
		Char reply;
		
		std::cerr << "\n*** Range Error (line " << line << " in " << file <<
			"): " << rangeMessage << std::endl;	
		std::cerr << "    Continue? [y/n] ";
		std::cin >> reply;
		
		if (reply != 'y')
		{
			DebuggerBreak();
			exit(1);
		}
	}
}

} // namespace vl
