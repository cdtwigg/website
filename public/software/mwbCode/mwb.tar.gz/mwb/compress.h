#ifndef __COMPRESS_H__
#define __COMPRESS_H__

void compress( const std::deque<Simulation::State>& states );

#endif
